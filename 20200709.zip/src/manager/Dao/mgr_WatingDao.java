package manager.Dao;

public class mgr_WatingDao {

}

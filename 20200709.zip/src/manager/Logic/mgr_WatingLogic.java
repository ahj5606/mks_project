package manager.Logic;

public class mgr_WatingLogic {

}
